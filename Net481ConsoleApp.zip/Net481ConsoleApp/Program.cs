﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Net481ConsoleApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Program obj = new Program();
            obj.LoadArm64dll();
        }
        public void LoadArm64dll()
        {
            Assembly assembly;

            try
            {
                //get the requested type from current assembly               
                var assemblyPath = "D:\\NetMAUIApp\\bin\\Release\\net8.0-maccatalyst\\maccatalyst-arm64\\NetMAUIApp.dll";
                Console.WriteLine("Testing to load maccatalyst-arm64 dll");
                assembly = Assembly.LoadFrom(assemblyPath);//this crashes coz it is an unmanaged dll called from managed dll

                //assembly = Assembly.ReflectionOnlyLoadFrom(assemblyPath);//Doesn't work on Net 7 or 8 because it is obsolete

                //assembly = Assembly.ReflectionOnlyLoad(assemblyPath); //crash

                assembly = Assembly.LoadFrom(assemblyPath);

            }
            catch (Exception e)
            {
                //Console.WriteLine("Could not load assembly due to bad image exception");
                Console.WriteLine(e);
                throw;
            }

        }

    }
}
